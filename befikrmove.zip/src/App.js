import React from 'react';
import IndexPage from './pages/IndexPage';

function App() {
  return (
    <>
    <IndexPage/>
    </>
  );
}

export default App;
